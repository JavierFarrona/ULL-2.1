#include <iostream>
#include "Alphabet.h"
#include "Symbols.h"

const char SPACE = ' ';
const char COMA = ',';
/*
/// Constructor
Alphabet::Alphabet(std::string& alphabet) {
  for (const auto& elem : alphabet) {
    Symbol symbol = elem;
    add(symbol);
  }
}


 *  @brief Sobrecarga del operador <<
 *  @param[out] out
 *  @param[in] alphabet
 
std::ostream& operator<<(std::ostream& out, const Alphabet& alphabet) {
  out << "[ ";
  for (const auto& symbol : alphabet.getAlphabet()) {
    out << symbol.getSymbol() << SPACE;
  }
  out << "]";
  return out;
}

 *  @brief Comprueba si un símbolo pertenece a un alfabeto
 *  @param[in] symbol
 *  @return True si pertenece, false si no
 
bool Alphabet::find(Symbol symbol) {
  bool found = false;
  for (const auto& elem : getAlphabet()) {
    if (symbol.getSymbol() == elem.getSymbol()) found = true;
  }
  return found;
}


 *  @brief Añade un símbolo a un alfabeto (si no lo contiene ya)
 *  @param[in] symbol
 
void Alphabet::add(Symbol symbol) {
  if (!find(symbol)) {
    alphabet_.push_back(symbol);
    ++size_;
  } 
}
*/

/programa los métodos del documento Alphabet.h

/// Constructor

Alphabet::Alphabet(std::string& alphabet) {
  for (const auto& elem : alphabet) {
    Symbol symbol = elem;
    add(symbol);
  }
}

/// Sobrecarga del operador <<

std::ostream& operator<<(std::ostream& out, const Alphabet& alphabet) {
  out << "[ ";
  for (const auto& symbol : alphabet.getAlphabet()) {
    out << symbol.getSymbol() << COMA << SPACE;
  }
  out << "]";
  return out;
}

/// Comprueba si un símbolo pertenece a un alfabeto

bool Alphabet::find(Symbol symbol) {
  bool found = false;
  for (const auto& elem : getAlphabet()) {
    if (symbol.getSymbol() == elem.getSymbol()) found = true;
  }
  return found;
}

/// Añade un símbolo a un alfabeto (si no lo contiene ya)

void Alphabet::add(Symbol symbol) {
  if (!find(symbol)) {
    alphabet_.insert(symbol);
    ++size_;
  } 
}
